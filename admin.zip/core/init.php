<?php
//Server name
$servername = "localhost";

//server username
$username = "root";

//server password
$db_password = "";

//Database name
$dbname = "school";
?>